package com.nhatnam.server.repository.pos;

import com.nhatnam.server.entity.Product;
import com.nhatnam.server.entity.pos.PosCategory;
import com.nhatnam.server.entity.pos.PosProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface PosProductRepository extends JpaRepository<PosProduct, Long> {
    List<PosProduct> findByCategoryId(Long categoryId);

    List<PosProduct> findByStoreId(Long storeId);

    /** Dùng trong PosService — lọc theo store */
    List<PosProduct> findByStoreIdAndIsActiveTrueOrderByDisplayOrderAscNameAsc(Long storeId);

    /** Dùng trong PosService — lọc theo category (category đã verify thuộc store) */
    List<PosProduct> findByCategoryAndIsActiveTrueOrderByDisplayOrderAscNameAsc(PosCategory category);

    /** Dùng trong PosExcelReportService — lấy product kèm category (tránh LazyInit) */
    @Query("SELECT p FROM PosProduct p JOIN FETCH p.category WHERE p.id = :id")
    Optional<PosProduct> findByIdWithCategory(@Param("id") Long id);

}